[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [ValidateSet('fr', 'en')]
    [string] $Edition
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$root = Split-Path -Parent $PSScriptRoot
$source = Join-Path $root $Edition
$output = Join-Path (Join-Path $root 'out') $Edition
$engine = Get-Command 'xelatex' -ErrorAction Stop
New-Item -ItemType Directory -Path $output -Force | Out-Null

Push-Location -LiteralPath $source
try {
    foreach ($pass in 1..2) {
        & $engine.Source '-interaction=nonstopmode' '-halt-on-error' `
            '-file-line-error' "-output-directory=$output" 'main.tex'
        if ($LASTEXITCODE -ne 0) {
            throw "XeLaTeX pass $pass failed with exit code $LASTEXITCODE"
        }
    }
}
finally {
    Pop-Location
}

$pdf = Join-Path $output 'main.pdf'
if (-not (Test-Path -LiteralPath $pdf -PathType Leaf)) {
    throw "Expected PDF was not produced: $pdf"
}
Get-Item -LiteralPath $pdf
