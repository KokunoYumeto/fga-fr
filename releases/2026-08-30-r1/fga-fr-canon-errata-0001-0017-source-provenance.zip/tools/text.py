"""Extract the existing PDF text layer as a fallible alignment witness.

This performs no OCR.  Mathematical content must be checked against renders.
Usage: python text.py INPUT.pdf OUTPUT.txt
"""

from __future__ import annotations

import sys
from pathlib import Path

from pypdf import PdfReader


def main() -> int:
    if len(sys.argv) != 3:
        raise SystemExit("usage: text.py INPUT.pdf OUTPUT.txt")

    source = Path(sys.argv[1]).resolve(strict=True)
    output = Path(sys.argv[2]).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    reader = PdfReader(source)
    blocks = []
    for page_number, page in enumerate(reader.pages, start=1):
        blocks.append(
            f"\n===== PHYSICAL PAGE {page_number:03d} =====\n\n"
            + (page.extract_text() or "")
        )
    output.write_text("".join(blocks), encoding="utf-8", newline="\n")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
